## Connection-Oriented Protocol vs Connectionless Protocol

```sheet
{
    classes: { 
        class1: { 
            "color": "cyan",
            "align": "center",
            "padding-top": "78px",
            "padding-bottom": "78px",
        },
        class2: {
            "align": "center",
            "padding-top": "85px",
            
        }
    }
}
---
|   Comparision parameter   |   Connection-Oriented Protocol   |   Conectionless Protocol   |
|   ---------------------   |   ----------------------------   |   ----------------------   |
|   Related System   |   Designed and developed based on the telephone system   |    Service based on the postal system    |
|   Definition   |    Used to create an end-to-end connection between the senders to the reciever before transmitting the data over same/different network   |   Used to transfer the data packets between senders to the reciever without creating any connection   |
|   Virtual Path   | Creates a virtual path between the sender and reciever   |   Does not create any virtual connection or path between the sender and the receiver   |
|   Authentication   |    Requires authentication before transmitting the data packets to the reciever   |   Does not requires authentication before transmitting the data packets to the reciever   |
|   Data Packets path   |   All data packets are recieved in the same order as those sent by the sender   |Not all data packets are recieved in same order as the those sent bythe reciever    |
|   Bandwidth Requirement   |   Requires a higher bandwidth to transfer the packets   |   Requires low bandwidth to transfer the packets   |
|   Data Reliability   |   More reliable connection service as it guarantees data packets transfer from  one end to the other end with a connection   |   Not a reliable connection service as it does not guarantee transfer of data packets from one end to another for establishing a connection   |
|   Congestion    |   No congestion as it provides an end-to-end connection between the send and reciever during transmission of data   |   May be congestion due to not providing an end-to-end connection between the source and reciever to transmit the data packets   |
|   Examples   |   TCP,MPLS,ATM   |   UDP,IP,ICMP   |
```
 

## IP Protocols
### [TCP(Transmission Control Protocol)](https://en.wikipedia.org/wiki/Transmission_Control_Protocol)
It provides a communication service for application program and IP. It provides host-to-host connectivity at the transport layer. An Application does not need to know the detailed mechanism for sending data via a link to another host. It needs IP fragmentation to accommodate the maximum transmission unit of the transmission medium.

At transport layer, it handles all the handshaking and transmission details and shows abstraction of the connection to the application by a socket interface. It also detects problems at lower level, requests re-transmission of lost data, rearranges out-of-order data and even minimizes the congestion. It focuses on accuracy instead of timely delivery.

### [UDP(User Datagram Protocol)](https://en.wikipedia.org/wiki/User_Datagram_Protocol)
It uses a simple connectionless model and provides [checksums](https://en.wikipedia.org/wiki/Checksum "Checksum") for data integrity, and [port numbers](https://en.wikipedia.org/wiki/Port_numbers "Port numbers") for addressing different functions at the source and destination of the datagram. It has no handshaking talks and exposes unreliability of the network; It doesn't guarantee of delivery, ordering,or duplication protection. It provides no error-correction facilities.

```sheet
{
    "classes": { 
        "class1": { 
            "align": "center",
            "padding-left": "250px"
        },
       "class2": { 
            "align": "center",
            "padding-left": "500px"
        },
        "class3": {
            "align": "center",
            "padding-left": "200px"
        }
    }
}

---
|_Offsets_|[Octet](https://en.wikipedia.org/wiki/Octet_(computing) "Octet (computing)")|0 ~.class1| < | < | < | < | < | < | < |1 ~.class1| < | < | < | < | < | < | < |2 ~.class1| < | < | < | < | < | < | < |3|   | < | < | < | < | < | < |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|[Octet](https://en.wikipedia.org/wiki/Octet_(computing) "Octet (computing)")|[Bit](https://en.wikipedia.org/wiki/Bit "Bit")|0|1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26|27|28|29|30|31|
|0|0|Source port ~.class4| < | < | < | < | < | < | < | < | < | < | < | < | < | < | < |Destination port ~.class5| < | < | < | < | < | < | < | < | < | < | < | < | < | < | < |
|4|32|Length ~.class4| < | < | < | < | < | < | < | < | < | < | < | < | < | < | < |Checksum ~.class5| < | < | < | < | < | < | < | < | < | < | < | < | < | < | < |
```

A number of UDP's attributes make it especially suited for certain applications.
- It is _transaction-oriented_, suitable for <span title="domain name system or the network time protocol" style="border-bottom: 1px dashed #999; cursor: help;color:#92d050;">simple query-response protocols</span>.
- It provides _[datagrams](https://en.wikipedia.org/wiki/Datagram)_, suitable for modeling other protocols such as [IP tunneling](https://en.wikipedia.org/wiki/IP_tunneling "IP tunneling") or [remote procedure call](https://en.wikipedia.org/wiki/Remote_procedure_call "Remote procedure call") and the [Network File System](https://en.wikipedia.org/wiki/Network_File_System "Network File System").
- It is _simple_, suitable for [bootstrapping](https://en.wikipedia.org/wiki/Bootstrapping "Bootstrapping") or other purposes without a full [protocol stack](https://en.wikipedia.org/wiki/Protocol_stack "Protocol stack"), such as the [DHCP](https://en.wikipedia.org/wiki/Dynamic_Host_Configuration_Protocol "Dynamic Host Configuration Protocol") and [Trivial File Transfer Protocol](https://en.wikipedia.org/wiki/Trivial_File_Transfer_Protocol "Trivial File Transfer Protocol").
- It is _stateless_ and the _lack of re-transmission delays_ makes it suitable for  <span title="VoIP,online games and many protocols using real time streaming protocol" style="border-bottom: 1px dashed #999; cursor: help;color:#92d050;">real-time applications</span>.
- Because it supports [multicast](https://en.wikipedia.org/wiki/Multicast "Multicast"), it is suitable for broadcast information such as in many kinds of [service discovery](https://en.wikipedia.org/wiki/Service_discovery "Service discovery") and shared information such as [Precision Time Protocol](https://en.wikipedia.org/wiki/Precision_Time_Protocol "Precision Time Protocol") and [Routing Information Protocol](https://en.wikipedia.org/wiki/Routing_Information_Protocol "Routing Information Protocol")
### [ICMP(Internet Control Message Protocol)](https://en.wikipedia.org/wiki/Internet_Control_Message_Protocol)
It is a protocol designed to report error messages and operational information indicating success/failure when communicating with another address. 

the **traceroute** command can be implemented  by transmitting IP datagram  with specially set IP TTL headers field ,and looking for ICMP time exceeded in transit and  Destination unreachable messages generated in response. the **ping** utility is implemented using the ICMP _echo request_ and _echo reply_.
It lacks a TCP/UDP port number as its packets are associated with the transport layer.
#### Datagram structure
<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e1/ICMP_header_-_General-en.svg/350px-ICMP_header_-_General-en.svg.png" alt =" Genral header for ICMPv4" style="background-color: #ffffff;">
The ICMP packet is encapsulated in an IPv4 packet. The packet consists of header and data sections.
##### Header
The ICMP header starts after the [IPv4 header](https://en.wikipedia.org/wiki/IPv4#Header "IPv4") and is identified by [IP protocol number](https://en.wikipedia.org/wiki/List_of_IP_protocol_numbers "List of IP protocol numbers") . All ICMP packets have an 8-byte header and variable-sized data section. The first 4 bytes of the header have fixed format, while the last 4 bytes depend on the type/code of that ICMP packet.

```sheet
{
	"classes":{
		"class1":{
		"align": "center",
		"padding-left": "250px"
		},
		"class2":{
		"align": "center",
		"padding-left": "750px"
		}
	}
}
---
| Offsets  | Octet | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 | 25 | 26 | 27 | 28 | 29 | 30 | 31 |
|---------|-------|---|---|---|---|---|---|---|---|---|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|----|
| 0       | 0     | Type ~.class1 | < | < | < | < | < | < | < | Code ~.class1 | < | < | < | < | < | < | < | Checksum ~.class1 |  < |  < |  < |  < |  < |  < |  < | < |  < |  < |  < |  < | < |  < |  < | < |
| 4       | 32    | Rest of the Header ~.class2 | < | < | < | < | < | < | < | < | < | < | < | < | < | < |  < | < |  < |  < |  < |  < |  < |  < |  < | < | < | < | < |
```
##### Type
ICMP type, see [§ Control messages](https://en.wikipedia.org/wiki/Internet_Control_Message_Protocol#Control_messages).
##### Code
ICMP subtype, see [§ Control messages](https://en.wikipedia.org/wiki/Internet_Control_Message_Protocol#Control_messages).
##### Checksum
[Internet checksum](https://en.wikipedia.org/wiki/Internet_checksum "Internet checksum") (RFC 1071) for error checking, calculated from the ICMP header and data with value 0 substituted for this field.
##### Rest of header
Four-byte field, contents vary based on the ICMP type and code.
#### Data
ICMP error messages contain a data section that includes a copy of the entire IPv4 header, plus at least the first eight bytes of data from the IPv4 packet that caused the error message. The length of ICMP error messages should not exceed 576 bytes. This data is used by the host to match the message to the appropriate process. If a higher level protocol uses port numbers, they are assumed to be in the first eight bytes of the original datagram's data.

The variable size of the ICMP packet data section has been [exploited](https://en.wikipedia.org/wiki/Exploit_(computer_security) "Exploit (computer security)"). In the "[Ping of death](https://en.wikipedia.org/wiki/Ping_of_death "Ping of death")", large or fragmented ICMP packets are used for [denial-of-service attacks](https://en.wikipedia.org/wiki/Denial-of-service_attacks "Denial-of-service attacks"). ICMP data can also be used to create [covert channels](https://en.wikipedia.org/wiki/Covert_channels "Covert channels") for communication called [ICMP tunnels](https://en.wikipedia.org/wiki/ICMP_tunnel "ICMP tunnel").
### [IPSec(**Internet Protocol Security**)](https://en.wikipedia.org/wiki/IPsec)
It is security protocol suite which authenticates and encrypts packets of data.
It is a part of IPv4 suite and uses following protocols to perform various functions:
#### **AH(Authenticator Header)** 
It gives connectionless data  integrity by using a [hash function](https://en.wikipedia.org/wiki/Hash_function "Hash function") ,and secret key in the Algorithm ,and data origin authentication for IP datagrams  by authenticating packets ,and provides protection against [replay attacks](https://en.wikipedia.org/wiki/Replay_attack "Replay attack") using [sliding window](https://en.wikipedia.org/wiki/Sliding_window "Sliding window") technique and discarding old packets.
It operates on IP, using [IP protocol number 51](https://en.wikipedia.org/wiki/List_of_IP_protocol_numbers "List of IP protocol numbers")
```sheet
{
	"classes": {
		"class1": {
			"align": "center"
		}
	}
}
---
| IPv4 | IPv6 |
| ---- | ---- |
| Prevents option-insertion attacks | Protects against both header insertion and option-insertion attacks |
| Protects the payload and all header fields of the datagram except for mutable fields(DSCP/ToS, ECN, Flags, Fragment Offset, TTL and header Checksum), and also IP Security Options(RFC 1108) | Protects most of the basic header, non-mutable extensions  headers after the AH, and the payload. Protection excludes the mutable fields: DSCP, ECN, Flow Label, and Hop Limit|
```
##### AH packet 
```sheet
{
	"classes": {
		"class1":{
		}
	}
}
| **Authentication Header format** | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|_Offsets_| 100m$_2$|0| < | < | < | < | < | < | < |1| < | < | < | < | < | < | < |2| < | < | < | < | < | < |   |3| < | < | < | < | < | < | < |
|Octet16|Bit10|0|1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26|27|28|29|30|31|
|0|0|_Next Header_| < | < | < | < | < | < |   |_Payload Len_| < | < | < | < | < | < |   |_Reserved_| < | < | < | < | < | < | < | < | < | < | < | < | < | < | < |
|4|32|_Security Parameters Index (SPI)_| < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < |
|8|64|_Sequence Number_| < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < |
|C|96|_Integrity Check Value (ICV)_ | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < |
|...|...| ^ | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < | < |
```

###### _Next Header_ (8 bits)
Type of the next header, indicating what upper-layer protocol was protected. The value is taken from the [list of IP protocol numbers](https://en.wikipedia.org/wiki/List_of_IP_protocol_numbers "List of IP protocol numbers").
###### _Payload Len_ (8 bits)
The length of this _Authentication Header_ in 4-octet units, minus 2. For example, an AH value of 4 equals 3×(32-bit fixed-length AH fields) + 3×(32-bit ICV fields) − 2 and thus an AH value of 4 means 24 octets. Although the size is measured in 4-octet units, the length of this header needs to be a multiple of 8 octets if carried in an IPv6 packet. This restriction does not apply to an _Authentication Header_ carried in an IPv4 packet.
###### _Reserved_ (16 bits)
Reserved for future use (all zeroes until then).
###### _Security Parameters Index_ (32 bits)
Arbitrary value which is used (together with the destination IP address) to identify the [security association](https://en.wikipedia.org/wiki/Security_association "Security association") of the receiving party.
###### _Sequence Number_ (32 bits)
A [monotonic](https://en.wikipedia.org/wiki/Monotonic "Monotonic") strictly increasing sequence number (incremented by 1 for every packet sent) to prevent [replay attacks](https://en.wikipedia.org/wiki/Replay_attack "Replay attack"). When replay detection is enabled, sequence numbers are never reused, because a new security association must be renegotiated before an attempt to increment the sequence number beyond its maximum value.
###### _Integrity Check Value_ (multiple of 32 bits)
Variable length check value. It may contain padding to align the field to an 8-octet boundary for [IPv6](https://en.wikipedia.org/wiki/IPv6 "IPv6"), or a 4-octet boundary for [IPv4](https://en.wikipedia.org/wiki/IPv4 "IPv4").

### ARP

### DNS

### DHCP

## FTP

### HTTP

### SMTP

### Telnet